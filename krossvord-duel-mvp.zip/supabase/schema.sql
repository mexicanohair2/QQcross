create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key default gen_random_uuid(),
 username text not null,
 username_normalized text generated always as (lower(username)) stored unique,
 avatar_id smallint not null check (avatar_id between 1 and 10),
 coins integer not null default 0 check (coins >= 0),
 wins integer not null default 0,
 games_played integer not null default 0,
 total_points integer not null default 0,
 created_at timestamptz not null default now(),
 check (username ~ '^[A-Za-z0-9_]{3,16}$')
);
create table if not exists public.recovery_codes (
 player_id uuid primary key references public.profiles(id) on delete cascade,
 code_hash text not null,
 created_at timestamptz not null default now()
);
create table if not exists public.friendships (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references public.profiles(id) on delete cascade,
 receiver_id uuid not null references public.profiles(id) on delete cascade,
 status text not null default 'pending' check(status in ('pending','accepted','rejected','cancelled')),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 check(sender_id<>receiver_id),
 unique(sender_id,receiver_id)
);
create table if not exists public.game_invites (
 id uuid primary key default gen_random_uuid(),
 match_id uuid,
 sender_id uuid not null references public.profiles(id) on delete cascade,
 receiver_id uuid not null references public.profiles(id) on delete cascade,
 status text not null default 'pending' check(status in ('pending','accepted','rejected','cancelled','expired')),
 expires_at timestamptz not null default now()+interval '60 seconds',
 created_at timestamptz not null default now()
);
create table if not exists public.crosswords (
 id text primary key, title text not null,
 difficulty text not null check(difficulty in ('easy','medium','hard')),
 width integer not null, height integer not null,
 grid jsonb not null, words jsonb not null,
 is_active boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.matches (
 id uuid primary key default gen_random_uuid(),
 code text not null unique,
 crossword_id text not null references public.crosswords(id),
 host_id uuid not null references public.profiles(id),
 status text not null default 'lobby' check(status in ('lobby','active','finished','cancelled')),
 current_player_index integer not null default 0,
 turn_started_at timestamptz,
 turn_duration_seconds integer not null default 60,
 consecutive_idle_turns integer not null default 0,
 created_at timestamptz not null default now(), finished_at timestamptz
);
create table if not exists public.match_players (
 match_id uuid not null references public.matches(id) on delete cascade,
 player_id uuid not null references public.profiles(id),
 player_order integer not null, score integer not null default 0,
 words_completed integer not null default 0, correct_letters integer not null default 0,
 hand jsonb not null default '[]',
 items jsonb not null default '{"magnifier":0,"clock":0,"trash":0}',
 status text not null default 'waiting' check(status in ('waiting','ready','playing','offline','finished')),
 primary key(match_id,player_id), unique(match_id,player_order)
);
create table if not exists public.match_cells (
 match_id uuid not null references public.matches(id) on delete cascade,
 cell_index integer not null, letter char(1) not null,
 player_id uuid not null references public.profiles(id),
 created_at timestamptz not null default now(),
 primary key(match_id,cell_index)
);
create table if not exists public.match_events (
 id bigint generated always as identity primary key,
 match_id uuid not null references public.matches(id) on delete cascade,
 player_id uuid references public.profiles(id),
 event_type text not null, payload jsonb not null default '{}',
 created_at timestamptz not null default now()
);
create table if not exists public.match_results (
 match_id uuid not null references public.matches(id) on delete cascade,
 player_id uuid not null references public.profiles(id),
 place integer not null, score integer not null, coins_earned integer not null,
 primary key(match_id,player_id)
);
create table if not exists public.match_history (
 player_id uuid not null references public.profiles(id) on delete cascade,
 match_id uuid not null references public.matches(id) on delete cascade,
 played_at timestamptz not null default now(), primary key(player_id,match_id)
);
create index if not exists idx_friendships_receiver on public.friendships(receiver_id,status);
create index if not exists idx_invites_receiver on public.game_invites(receiver_id,status);
create index if not exists idx_matches_status on public.matches(status);
create index if not exists idx_match_events_match on public.match_events(match_id,id);

-- RLS включён сразу. Доступ к данным выдаётся через безопасные RPC/Edge Functions.
alter table public.profiles enable row level security;
alter table public.recovery_codes enable row level security;
alter table public.friendships enable row level security;
alter table public.game_invites enable row level security;
alter table public.crosswords enable row level security;
alter table public.matches enable row level security;
alter table public.match_players enable row level security;
alter table public.match_cells enable row level security;
alter table public.match_events enable row level security;
alter table public.match_results enable row level security;
alter table public.match_history enable row level security;

-- Пока нет клиентских политик: таблицы закрыты. Не добавляйте permissive policies
-- до реализации аутентификации и проверки прав на сервере.
